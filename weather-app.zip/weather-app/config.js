// ── Nimbus Weather App · Configuration ──────────────────────────────────────
// Replace the value below with your free API key from https://openweathermap.org/api
// Sign up → My API Keys → copy your key

const CONFIG = {
  API_KEY: "YOUR_OPENWEATHERMAP_API_KEY",   // ← paste your key here
  BASE_URL: "https://api.openweathermap.org/data/2.5",
  GEO_URL: "https://api.openweathermap.org/geo/1.0",
  AQI_URL: "https://api.openweathermap.org/data/2.5/air_pollution",
  REFRESH_INTERVAL_MS: 10 * 60 * 1000,     // 10 minutes
};
